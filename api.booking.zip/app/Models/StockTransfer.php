<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StockTransfer extends Model
{
    use HasFactory, SoftDeletes;
    protected $guarded = ["id"];

    const STOCK_TRANSFER_STATUS_TRANSFERRED = "transferred";
}
